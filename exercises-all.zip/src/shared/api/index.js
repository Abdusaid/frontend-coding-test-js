export * as ApiChucknorris from './chucknorris'
