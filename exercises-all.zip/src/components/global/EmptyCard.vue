<template>
  <div class="mb-2 text-2xl font-bold italic">
    There are no any jokes in this category!
  </div>
</template>
